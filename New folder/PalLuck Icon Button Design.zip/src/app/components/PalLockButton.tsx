import { useState } from 'react';
import logoImage from 'figma:asset/ee6431f350629f1a979007df283bec2acda1616d.png';

interface PalLockButtonProps {
  onClick?: () => void;
  size?: number;
}

export function PalLockButton({ onClick, size = 120 }: PalLockButtonProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  return (
    <button
      onClick={onClick}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onMouseLeave={() => {
        setIsPressed(false);
        setIsHovered(false);
      }}
      onMouseEnter={() => setIsHovered(true)}
      className="relative transition-all duration-200 ease-out focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-400/50"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        transform: isPressed ? 'scale(0.95)' : isHovered ? 'scale(1.05)' : 'scale(1)',
      }}
      aria-label="Pal-lock-uck logo button"
    >
      {/* Outer glow effect on hover */}
      <div
        className="absolute inset-0 rounded-3xl transition-opacity duration-300"
        style={{
          background: 'radial-gradient(circle, rgba(94, 176, 255, 0.6) 0%, rgba(94, 176, 255, 0) 70%)',
          opacity: isHovered ? 1 : 0.6,
          filter: 'blur(30px)',
          transform: 'scale(1.3)',
        }}
      />
      
      {/* Pulsing animation */}
      <style>
        {`
          @keyframes pulse-glow {
            0%, 100% {
              opacity: 0.8;
              filter: drop-shadow(0 0 15px rgba(94, 176, 255, 0.6));
            }
            50% {
              opacity: 1;
              filter: drop-shadow(0 0 25px rgba(94, 176, 255, 0.9));
            }
          }
          
          .logo-pulse {
            animation: pulse-glow 2s ease-in-out infinite;
          }
        `}
      </style>
      
      {/* Main logo container with border */}
      <div
        className="relative w-full h-full rounded-3xl overflow-visible logo-pulse"
        style={{
          boxShadow: isHovered 
            ? '0 20px 60px rgba(153, 24, 102, 0.5), 0 10px 30px rgba(26, 8, 96, 0.6), 0 0 40px rgba(94, 176, 255, 0.8)'
            : '0 10px 30px rgba(153, 24, 102, 0.4), 0 5px 15px rgba(26, 8, 96, 0.5), 0 0 20px rgba(94, 176, 255, 0.5)',
          border: '2px solid rgba(94, 176, 255, 0.6)',
        }}
      >
        {/* Inner container for clipping */}
        <div className="absolute inset-0 rounded-3xl overflow-hidden">
          {/* Background gradient */}
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(135deg, #991866 0%, #1A0860 100%)',
            }}
          />
          
          {/* Ambient blue orb glow */}
          <div
            className="absolute"
            style={{
              width: '88%',
              height: '88%',
              top: '6%',
              left: '6%',
              background: 'radial-gradient(circle, rgba(74, 144, 226, 0.3) 0%, rgba(74, 144, 226, 0) 60%)',
              filter: 'blur(40px)',
              opacity: isHovered ? 1 : 0.7,
              transition: 'opacity 0.3s ease',
            }}
          />
        </div>
        
        {/* Logo image with 3D pop-out effect */}
        <div className="absolute inset-0 p-2" style={{ perspective: '1000px' }}>
          <img
            src={logoImage}
            alt="Pal-lock-uck Logo"
            className="w-full h-full object-contain"
            style={{
              filter: isHovered 
                ? 'brightness(1.2) contrast(1.15) drop-shadow(0 8px 16px rgba(0, 0, 0, 0.6)) drop-shadow(0 0 30px rgba(94, 176, 255, 0.8)) drop-shadow(0 4px 8px rgba(255, 255, 255, 0.3))'
                : 'brightness(1.1) contrast(1.1) drop-shadow(0 6px 12px rgba(0, 0, 0, 0.5)) drop-shadow(0 0 20px rgba(94, 176, 255, 0.6)) drop-shadow(0 2px 4px rgba(255, 255, 255, 0.2))',
              transition: 'filter 0.3s ease, transform 0.3s ease',
              transform: isHovered ? 'translateZ(15px) scale(1.02)' : 'translateZ(8px)',
              transformStyle: 'preserve-3d',
            }}
          />
        </div>
        
        {/* Additional inner glow on hover */}
        <div
          className="absolute inset-0 rounded-3xl transition-opacity duration-300 pointer-events-none"
          style={{
            background: 'radial-gradient(circle at 50% 45%, rgba(94, 176, 255, 0.25) 0%, transparent 50%)',
            opacity: isHovered ? 1 : 0,
          }}
        />
      </div>
      
      {/* Outer ring effect on press */}
      <div
        className="absolute inset-0 rounded-3xl transition-all duration-200 pointer-events-none"
        style={{
          boxShadow: isPressed ? 'inset 0 0 20px rgba(0, 0, 0, 0.5)' : 'none',
        }}
      />
    </button>
  );
}