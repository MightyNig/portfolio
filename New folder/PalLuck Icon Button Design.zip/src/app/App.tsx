import { PalLockButton } from './components/PalLockButton';

export default function App() {
  const handleClick = () => {
    console.log('Pal-lock-uck button clicked!');
    // Add your custom action here
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900">
      <div className="flex flex-col items-center gap-8">
        <PalLockButton onClick={handleClick} size={200} />
        
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-white tracking-wide">
            Locking with Your Pals
          </h1>
          <p className="text-purple-200/70 text-sm">Click the button to interact</p>
        </div>
      </div>
    </div>
  );
}
