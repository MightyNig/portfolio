
  # Create Icon Button Design

  This is a code bundle for Create Icon Button Design. The original project is available at https://www.figma.com/design/mtEC7Kec4xwlR5p47MA68m/Create-Icon-Button-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  