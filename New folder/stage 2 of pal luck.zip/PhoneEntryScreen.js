/**
 * PhoneEntryScreen.js
 * Pal-Luck — Stage 2: Phone Number Input
 *
 * Design contract:
 *  • Same deep iPhone-glow dark background as LandingScreen (no jarring switch)
 *  • Inline "Pal-[lock]uck" wordmark + motto, scaled down from Stage 1
 *  • Frosted-glass input row (country code + number) with soft blue focus glow
 *  • Continue button is dim when empty, fully lit when a number is typed
 *  • KeyboardAvoidingView keeps the button above the keyboard at all times
 *  • Tap outside → keyboard dismisses instantly (TouchableWithoutFeedback)
 *  • Back arrow (top-left) + swipe-down gesture both return to Stage 1
 */

import React, {
  useState,
  useRef,
  useCallback,
  useEffect,
} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Keyboard,
  Platform,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import {
  PanGestureHandler,
  GestureHandlerRootView,
  State,
} from 'react-native-gesture-handler';

// ─── Design tokens (shared with LandingScreen) ─────────────────────────────
const COLORS = {
  // Background gradient stops — identical to LandingScreen
  bgBase:       '#09071A',
  bgRose:       '#6A0E55',
  bgViolet:     '#2A0D82',
  bgDeep:       '#0A1040',

  // Brand / accent
  blue:         '#5EB0FF',
  blueCore:     '#2979FF',
  blueDim:      'rgba(94,176,255,0.18)',
  blueGlow:     'rgba(94,176,255,0.55)',
  blueRing:     'rgba(94,176,255,0.25)',

  // Text
  white:        '#FFFFFF',
  white90:      'rgba(255,255,255,0.90)',
  white70:      'rgba(255,255,255,0.70)',
  white45:      'rgba(255,255,255,0.45)',
  white25:      'rgba(255,255,255,0.25)',
  white12:      'rgba(255,255,255,0.12)',
  white08:      'rgba(255,255,255,0.08)',

  // Glass card
  glass:        'rgba(255,255,255,0.88)',
  glassBorder:  'rgba(255,255,255,0.55)',
  glassDivider: 'rgba(74,158,255,0.18)',

  // Input
  inputBg:      'rgba(255,255,255,0.75)',
  inputBorder:  'rgba(74,158,255,0.22)',
  inputFocus:   '#5EB0FF',
  placeholder:  '#BCC5D4',

  // Button
  btnActive:    '#3A8EFF',
  btnDim:       'rgba(94,176,255,0.28)',
  btnText:      '#FFFFFF',

  // Utility
  dark:         '#0D1220',
  muted:        '#8892A4',
  trustBlue:    '#4A6A98',
};

const FONTS = {
  brand:  'DancingScript-Bold',    // same script font as logo
  ui:     'DMSans-Regular',
  uiMed:  'DMSans-Medium',
  uiSemi: 'DMSans-SemiBold',
  serif:  'CormorantGaramond-LightItalic',
  hint:   'Italiana-Regular',
};

const { width: SW, height: SH } = Dimensions.get('window');

// ─── Dummy country list ─────────────────────────────────────────────────────
const COUNTRIES = [
  { flag: '🇺🇸', name: 'United States', code: '+1'   },
  { flag: '🇬🇧', name: 'United Kingdom', code: '+44'  },
  { flag: '🇳🇬', name: 'Nigeria',        code: '+234' },
  { flag: '🇬🇭', name: 'Ghana',          code: '+233' },
  { flag: '🇿🇦', name: 'South Africa',   code: '+27'  },
  { flag: '🇰🇪', name: 'Kenya',          code: '+254' },
  { flag: '🇩🇪', name: 'Germany',        code: '+49'  },
  { flag: '🇫🇷', name: 'France',         code: '+33'  },
  { flag: '🇦🇺', name: 'Australia',      code: '+61'  },
  { flag: '🇮🇳', name: 'India',          code: '+91'  },
];


// ───────────────────────────────────────────────────────────────────────────
export default function PhoneEntryScreen({ navigation }) {
// ───────────────────────────────────────────────────────────────────────────

  // ── State ────────────────────────────────────────────────────────────────
  const [phone,     setPhone]     = useState('');
  const [focused,   setFocused]   = useState(false);
  const [country,   setCountry]   = useState(COUNTRIES[0]);
  const [pickerOpen, setPickerOpen] = useState(false);

  // ── Refs ─────────────────────────────────────────────────────────────────
  const inputRef     = useRef(null);
  const swipeYRef    = useRef(new Animated.Value(0)).current;   // for swipe-down
  const screenAnim   = useRef(new Animated.Value(0)).current;   // entry slide-up

  // ── Entry animation (slides up from below when screen mounts) ───────────
  useEffect(() => {
    Animated.spring(screenAnim, {
      toValue: 1,
      damping: 22,
      stiffness: 180,
      useNativeDriver: true,
    }).start();
  }, []);

  const screenTranslateY = screenAnim.interpolate({
    inputRange:  [0, 1],
    outputRange: [SH, 0],
  });

  // ── Phone formatter (US-style for now; expand per country later) ─────────
  const formatPhone = useCallback((raw) => {
    const digits = raw.replace(/\D/g, '').slice(0, 10);
    if (digits.length > 6)
      return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6)}`;
    if (digits.length > 3)
      return `(${digits.slice(0,3)}) ${digits.slice(3)}`;
    return digits;
  }, []);

  const handlePhoneChange = (text) => setPhone(formatPhone(text));

  // ── Is the Continue button active? ──────────────────────────────────────
  const phoneDigits  = phone.replace(/\D/g, '');
  const isReady      = phoneDigits.length >= 7;

  // ── Swipe-down to go back (PanGestureHandler) ───────────────────────────
  const onSwipeEvent = Animated.event(
    [{ nativeEvent: { translationY: swipeYRef } }],
    { useNativeDriver: true }
  );

  const onSwipeState = ({ nativeEvent }) => {
    if (nativeEvent.state === State.END) {
      if (nativeEvent.translationY > 80) {
        // Enough downward drag → go back
        goBack();
      } else {
        // Snap back
        Animated.spring(swipeYRef, {
          toValue: 0, useNativeDriver: true,
        }).start();
      }
    }
  };

  const goBack = useCallback(() => {
    Keyboard.dismiss();
    Animated.timing(screenAnim, {
      toValue: 0, duration: 380,
      useNativeDriver: true,
    }).start(() => navigation.goBack());
  }, [navigation]);

  const handleContinue = () => {
    if (!isReady) return;
    Keyboard.dismiss();
    // Navigate forward to OTP screen (Stage 3)
    navigation.navigate('Verification', {
      phone:       phone,
      countryCode: country.code,
    });
  };

  // ── Dismiss keyboard on outside tap ─────────────────────────────────────
  const dismissKeyboard = () => {
    Keyboard.dismiss();
    setPickerOpen(false);
  };

  // ── Focus glow anim value ────────────────────────────────────────────────
  const glowAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(glowAnim, {
      toValue: focused ? 1 : 0,
      duration: 220,
      useNativeDriver: false,   // shadow props can't use native driver
    }).start();
  }, [focused]);

  const inputShadowOpacity = glowAnim.interpolate({
    inputRange:  [0, 1],
    outputRange: [0.10, 0.55],
  });
  const inputShadowRadius = glowAnim.interpolate({
    inputRange:  [0, 1],
    outputRange: [4, 18],
  });
  const inputBorderColor = glowAnim.interpolate({
    inputRange:  [0, 1],
    outputRange: [COLORS.inputBorder, COLORS.inputFocus],
  });

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <GestureHandlerRootView style={styles.rootFlex}>

      {/* Dark status bar to match the gradient bg */}
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* ── Swipe-down gesture wrapper ── */}
      <PanGestureHandler
        onGestureEvent={onSwipeEvent}
        onHandlerStateChange={onSwipeState}
        activeOffsetY={[0, 15]}        // only start tracking after 15px downward
        failOffsetY={-15}              // let upward scroll through
      >
        <Animated.View
          style={[
            styles.rootFlex,
            {
              transform: [
                { translateY: screenTranslateY },
                {
                  // Clamp the swipe drag so it can only go down
                  translateY: swipeYRef.interpolate({
                    inputRange:  [-200, 0, 300],
                    outputRange: [-30,  0, 220],  // elastic resistance upward
                    extrapolate: 'clamp',
                  }),
                },
              ],
            },
          ]}
        >

          {/* ── Background: identical gradient to LandingScreen ── */}
          <View style={StyleSheet.absoluteFill}>
            {/* Base navy */}
            <View style={[StyleSheet.absoluteFill, { backgroundColor: COLORS.bgBase }]} />
            {/* Rose bloom — top-left */}
            <LinearGradient
              colors={['#991866', '#6A0E55', '#3A0840', 'transparent']}
              start={{ x: 0, y: 0 }} end={{ x: 0.7, y: 0.7 }}
              style={[StyleSheet.absoluteFill, { opacity: 0.58 }]}
            />
            {/* Violet/indigo — right side */}
            <LinearGradient
              colors={['transparent', '#2A0D82', '#1A0860', 'transparent']}
              start={{ x: 1, y: 0 }} end={{ x: 0.3, y: 0.8 }}
              style={[StyleSheet.absoluteFill, { opacity: 0.50 }]}
            />
            {/* Deep blue — bottom */}
            <LinearGradient
              colors={['transparent', '#0A1040', COLORS.bgBase]}
              start={{ x: 0.5, y: 0.5 }} end={{ x: 0.5, y: 1 }}
              style={[StyleSheet.absoluteFill, { opacity: 0.75 }]}
            />
          </View>

          {/* ── Tap-anywhere-to-dismiss keyboard ── */}
          <TouchableWithoutFeedback onPress={dismissKeyboard} accessible={false}>
            <View style={styles.rootFlex}>

              {/* ── KeyboardAvoidingView keeps Continue above keyboard ── */}
              <KeyboardAvoidingView
                style={styles.rootFlex}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                keyboardVerticalOffset={0}
              >

                {/* ── Back button ── */}
                <TouchableOpacity
                  style={styles.backBtn}
                  onPress={goBack}
                  hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  activeOpacity={0.65}
                >
                  <View style={styles.backBtnInner}>
                    {/* Chevron left */}
                    <Text style={styles.backChevron}>‹</Text>
                  </View>
                </TouchableOpacity>

                {/* ── Header: inline logo block ── */}
                <View style={styles.header}>
                  {/* Word row: "Pal-" [lock icon] "uck" */}
                  <View style={styles.wordRow}>
                    <Text style={styles.wordmark}>Pal-</Text>

                    {/* Inline lock — pure RN, no SVG dependency */}
                    <View style={styles.lockWrap}>
                      {/* Shackle (top arch) */}
                      <View style={styles.shackle} />
                      {/* Body */}
                      <View style={styles.lockBody}>
                        {/* Keyhole */}
                        <View style={styles.keyhole} />
                        <View style={styles.keyStem} />
                      </View>
                    </View>

                    <Text style={styles.wordmark}>uck</Text>
                  </View>

                  {/* Motto */}
                  <Text style={styles.motto}>Locking With Your Pals</Text>
                </View>

                {/* ── Frosted-glass card ── */}
                <View style={styles.cardWrap}>
                  <BlurView
                    intensity={60}
                    tint="light"
                    style={styles.card}
                  >
                    {/* Drag handle */}
                    <View style={styles.dragHandle} />

                    {/* Heading */}
                    <Text style={styles.heading}>
                      Let's get{'\n'}
                      <Text style={styles.headingAccent}>started.</Text>
                    </Text>
                    <Text style={styles.subheading}>
                      Enter your number to join your trusted network.
                    </Text>

                    {/* ── Input group ── */}
                    <Text style={styles.inputLabel}>MOBILE NUMBER</Text>

                    <Animated.View
                      style={[
                        styles.inputRow,
                        {
                          borderColor:   inputBorderColor,
                          shadowColor:   COLORS.blue,
                          shadowOpacity: inputShadowOpacity,
                          shadowRadius:  inputShadowRadius,
                          shadowOffset:  { width: 0, height: 0 },
                          elevation:     focused ? 10 : 2,
                        },
                      ]}
                    >
                      {/* Country code selector */}
                      <TouchableOpacity
                        style={styles.ccBtn}
                        onPress={() => {
                          Keyboard.dismiss();
                          setPickerOpen(v => !v);
                        }}
                        activeOpacity={0.7}
                      >
                        <Text style={styles.ccFlag}>{country.flag}</Text>
                        <Text style={styles.ccCode}>{country.code}</Text>
                        <Text style={styles.ccChev}>▾</Text>
                      </TouchableOpacity>

                      {/* Divider */}
                      <View style={styles.ccDivider} />

                      {/* Number input */}
                      <TextInput
                        ref={inputRef}
                        style={styles.numInput}
                        value={phone}
                        onChangeText={handlePhoneChange}
                        onFocus={() => setFocused(true)}
                        onBlur={() => setFocused(false)}
                        placeholder="(555) 000-0000"
                        placeholderTextColor={COLORS.placeholder}
                        keyboardType="phone-pad"
                        returnKeyType="done"
                        onSubmitEditing={handleContinue}
                        maxLength={14}
                        selectionColor={COLORS.blue}
                        autoComplete="tel"
                        textContentType="telephoneNumber"
                      />

                      {/* Clear button — appears once something is typed */}
                      {phone.length > 0 && (
                        <TouchableOpacity
                          style={styles.clearBtn}
                          onPress={() => {
                            setPhone('');
                            inputRef.current?.focus();
                          }}
                          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                        >
                          <View style={styles.clearCircle}>
                            <Text style={styles.clearX}>×</Text>
                          </View>
                        </TouchableOpacity>
                      )}
                    </Animated.View>

                    <Text style={styles.inputHelper}>
                      We'll send you a verification code via SMS
                    </Text>

                    {/* ── Trust pill ── */}
                    <View style={styles.trustPill}>
                      {/* Shield icon (pure RN) */}
                      <View style={styles.shieldWrap}>
                        <Text style={styles.shieldIcon}>🔒</Text>
                      </View>
                      <Text style={styles.trustText}>
                        <Text style={styles.trustBold}>End-to-end encrypted. </Text>
                        Your number is only shared with contacts you approve.
                      </Text>
                    </View>

                    {/* ── Spacer pushes button to bottom ── */}
                    <View style={styles.spacer} />

                    {/* ── Continue button ── */}
                    <TouchableOpacity
                      style={[
                        styles.continueBtn,
                        isReady ? styles.continueBtnActive : styles.continueBtnDim,
                      ]}
                      onPress={handleContinue}
                      disabled={!isReady}
                      activeOpacity={0.82}
                    >
                      {isReady ? (
                        <LinearGradient
                          colors={['#3A8EFF', '#2062E8']}
                          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                          style={styles.continueBtnGradient}
                        >
                          <Text style={styles.continueBtnText}>Continue</Text>
                        </LinearGradient>
                      ) : (
                        <View style={styles.continueBtnGradient}>
                          <Text style={[styles.continueBtnText, { opacity: 0.55 }]}>
                            Continue
                          </Text>
                        </View>
                      )}
                    </TouchableOpacity>

                    {/* Terms */}
                    <Text style={styles.terms}>
                      By continuing you agree to our{' '}
                      <Text style={styles.termsLink}>Terms of Service</Text>
                      {' '}and{' '}
                      <Text style={styles.termsLink}>Privacy Policy</Text>
                    </Text>

                  </BlurView>
                </View>

              </KeyboardAvoidingView>
            </View>
          </TouchableWithoutFeedback>

          {/* ── Country Picker modal (slides up from bottom) ── */}
          {pickerOpen && (
            <TouchableWithoutFeedback onPress={() => setPickerOpen(false)}>
              <View style={styles.pickerBackdrop}>
                <TouchableWithoutFeedback onPress={() => {}}>
                  <BlurView intensity={80} tint="light" style={styles.pickerSheet}>
                    <View style={styles.pickerHandle} />
                    <Text style={styles.pickerTitle}>Select Country</Text>
                    {COUNTRIES.map((c, i) => (
                      <TouchableOpacity
                        key={i}
                        style={[
                          styles.pickerItem,
                          country.code === c.code &&
                          country.name === c.name &&
                          styles.pickerItemSelected,
                        ]}
                        onPress={() => {
                          setCountry(c);
                          setPickerOpen(false);
                        }}
                        activeOpacity={0.7}
                      >
                        <Text style={styles.pickerFlag}>{c.flag}</Text>
                        <Text style={styles.pickerName}>{c.name}</Text>
                        <Text style={styles.pickerCode}>{c.code}</Text>
                      </TouchableOpacity>
                    ))}
                  </BlurView>
                </TouchableWithoutFeedback>
              </View>
            </TouchableWithoutFeedback>
          )}

        </Animated.View>
      </PanGestureHandler>
    </GestureHandlerRootView>
  );
}


// ─── Styles ─────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({

  rootFlex: {
    flex: 1,
  },

  // ── Back button ───────────────────────────────────────────────────────────
  backBtn: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 56 : 36,
    left: 20,
    zIndex: 50,
  },
  backBtnInner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.20)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backChevron: {
    fontSize: 26,
    color: COLORS.white70,
    lineHeight: 30,
    marginLeft: -2,   // optical nudge
  },

  // ── Header / logo ─────────────────────────────────────────────────────────
  header: {
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 110 : 90,
    paddingBottom: 24,
  },

  wordRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  wordmark: {
    fontFamily: FONTS.brand,
    fontSize: 40,
    color: COLORS.white,
    letterSpacing: -0.5,
    // Layered text shadow = the glow
    textShadowColor: COLORS.blue,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },

  // Inline lock (pure View-based, no SVG dep)
  lockWrap: {
    width: 28,
    height: 38,
    alignItems: 'center',
    marginTop: -4,        // align with script cap height
    // Outer glow via shadow
    shadowColor: COLORS.blue,
    shadowOpacity: 0.75,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
  },
  shackle: {
    width: 18,
    height: 12,
    borderTopLeftRadius: 9,
    borderTopRightRadius: 9,
    borderWidth: 3,
    borderColor: COLORS.white90,
    borderBottomWidth: 0,
    marginBottom: 0,
  },
  lockBody: {
    width: 28,
    height: 22,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 6,
    borderWidth: 1.8,
    borderColor: COLORS.white90,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyhole: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: COLORS.white90,
    marginBottom: 2,
  },
  keyStem: {
    width: 5,
    height: 5,
    borderRadius: 2,
    backgroundColor: COLORS.white90,
    marginTop: -2,
  },

  motto: {
    marginTop: 9,
    fontFamily: FONTS.serif,
    fontSize: 10.5,
    letterSpacing: 2.4,
    textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.42)',
  },

  // ── Glass card ────────────────────────────────────────────────────────────
  cardWrap: {
    flex: 1,
    borderTopLeftRadius: 36,
    borderTopRightRadius: 36,
    overflow: 'hidden',
    // Top highlight border
    borderTopWidth: 1,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    borderColor: 'rgba(255,255,255,0.50)',
    // Card shadow
    shadowColor: '#000',
    shadowOpacity: 0.28,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: -6 },
    elevation: 14,
  },

  card: {
    flex: 1,
    paddingHorizontal: 32,
    paddingBottom: Platform.OS === 'ios' ? 40 : 28,
    paddingTop: 0,
    // BlurView handles the frosted glass bg —
    // we add a semi-transparent white tint on top
    backgroundColor: 'rgba(255,255,255,0.82)',
  },

  dragHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(0,0,0,0.10)',
    alignSelf: 'center',
    marginTop: 14,
    marginBottom: 32,
  },

  // ── Typography ────────────────────────────────────────────────────────────
  heading: {
    fontFamily: FONTS.uiSemi,
    fontSize: 28,
    color: COLORS.dark,
    letterSpacing: -0.8,
    lineHeight: 34,
    marginBottom: 8,
  },
  headingAccent: {
    color: COLORS.blueCore,
  },
  subheading: {
    fontFamily: FONTS.ui,
    fontSize: 13.5,
    color: COLORS.muted,
    lineHeight: 20,
    marginBottom: 28,
  },

  // ── Input ─────────────────────────────────────────────────────────────────
  inputLabel: {
    fontFamily: FONTS.uiSemi,
    fontSize: 10.5,
    letterSpacing: 1.6,
    color: COLORS.muted,
    marginBottom: 10,
  },

  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.inputBg,
    borderRadius: 16,
    borderWidth: 1.5,
    // borderColor animated above
    overflow: 'hidden',
  },

  ccBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 16,
    gap: 6,
    minWidth: 88,
  },
  ccFlag: {
    fontSize: 20,
  },
  ccCode: {
    fontFamily: FONTS.uiMed,
    fontSize: 15,
    color: COLORS.dark,
  },
  ccChev: {
    fontSize: 11,
    color: COLORS.muted,
    marginLeft: 2,
  },

  ccDivider: {
    width: 1.5,
    height: 28,
    backgroundColor: COLORS.glassDivider,
  },

  numInput: {
    flex: 1,
    fontFamily: FONTS.ui,
    fontSize: 17,
    color: COLORS.dark,
    letterSpacing: 0.4,
    paddingHorizontal: 16,
    paddingVertical: 18,
  },

  clearBtn: {
    paddingRight: 14,
  },
  clearCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: COLORS.muted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  clearX: {
    color: COLORS.white,
    fontSize: 15,
    lineHeight: 20,
    fontFamily: FONTS.ui,
  },

  inputHelper: {
    fontFamily: FONTS.ui,
    fontSize: 12,
    color: COLORS.muted,
    marginTop: 10,
    marginBottom: 20,
  },

  // ── Trust pill ────────────────────────────────────────────────────────────
  trustPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 13,
    backgroundColor: 'rgba(74,158,255,0.07)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(74,158,255,0.18)',
  },
  shieldWrap: { flexShrink: 0 },
  shieldIcon: { fontSize: 16 },
  trustText: {
    flex: 1,
    fontFamily: FONTS.ui,
    fontSize: 12,
    color: COLORS.trustBlue,
    lineHeight: 17,
  },
  trustBold: {
    fontFamily: FONTS.uiSemi,
    color: COLORS.blueCore,
  },

  spacer: { flex: 1 },

  // ── Continue button ───────────────────────────────────────────────────────
  continueBtn: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 14,
  },
  continueBtnActive: {
    // Glow shadow when active
    shadowColor: COLORS.blueCore,
    shadowOpacity: 0.50,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 6 },
    elevation: 12,
  },
  continueBtnDim: {
    // No glow when empty
    shadowOpacity: 0,
    elevation: 0,
    backgroundColor: COLORS.btnDim,
  },
  continueBtnGradient: {
    paddingVertical: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 18,
  },
  continueBtnText: {
    fontFamily: FONTS.uiSemi,
    fontSize: 16,
    color: COLORS.white,
    letterSpacing: -0.2,
  },

  // ── Terms ─────────────────────────────────────────────────────────────────
  terms: {
    fontFamily: FONTS.ui,
    fontSize: 11,
    color: COLORS.placeholder,
    textAlign: 'center',
    lineHeight: 17,
  },
  termsLink: {
    color: COLORS.blueCore,
    fontFamily: FONTS.uiMed,
  },

  // ── Country picker ────────────────────────────────────────────────────────
  pickerBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.50)',
    justifyContent: 'flex-end',
    zIndex: 100,
  },
  pickerSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingBottom: 40,
    backgroundColor: 'rgba(255,255,255,0.94)',
    maxHeight: SH * 0.60,
    overflow: 'hidden',
  },
  pickerHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(0,0,0,0.10)',
    alignSelf: 'center',
    marginTop: 14,
    marginBottom: 4,
  },
  pickerTitle: {
    fontFamily: FONTS.uiSemi,
    fontSize: 16,
    color: COLORS.dark,
    textAlign: 'center',
    paddingVertical: 14,
  },
  pickerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(0,0,0,0.06)',
  },
  pickerItemSelected: {
    backgroundColor: 'rgba(74,158,255,0.08)',
  },
  pickerFlag: { fontSize: 24, marginRight: 14 },
  pickerName: {
    flex: 1,
    fontFamily: FONTS.ui,
    fontSize: 15,
    color: COLORS.dark,
  },
  pickerCode: {
    fontFamily: FONTS.uiMed,
    fontSize: 14,
    color: COLORS.muted,
  },
});
