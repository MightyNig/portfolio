/**
 * AppNavigator.js
 * Pal-Luck — Root Navigation Setup
 *
 * Stack:
 *   Landing (Stage 1) → PhoneEntry (Stage 2) → Verification (Stage 3)
 *   → ProfileSetup (Stage 4) → MainTabs (the full app)
 *
 * Transition design:
 *   • Landing  → PhoneEntry : slide up from bottom (card modal feel)
 *   • PhoneEntry → Verification : slide left (standard iOS push)
 *   • All onboarding screens share the same dark background so the
 *     context switch is never jarring.
 */

import React from 'react';
import { Platform, Easing } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator }  from '@react-navigation/stack';

// ── Screen imports ────────────────────────────────────────────────────────
import LandingScreen      from '../screens/LandingScreen';       // Stage 1
import PhoneEntryScreen   from '../screens/PhoneEntryScreen';    // Stage 2
import VerificationScreen from '../screens/VerificationScreen';  // Stage 3
import ProfileSetupScreen from '../screens/ProfileSetupScreen';  // Stage 4
// import MainTabNavigator from './MainTabNavigator';            // Stage 5+ (uncomment when ready)

const Stack = createStackNavigator();

// ─── Shared transition configs ─────────────────────────────────────────────

/**
 * SLIDE-UP (modal card feel)
 * Used for Landing → PhoneEntry so the phone-entry card
 * rises from below, like a bottom sheet.
 */
const slideUpTransition = {
  gestureEnabled:     true,
  gestureDirection:   'vertical',
  cardStyleInterpolator: ({ current, layouts }) => ({
    cardStyle: {
      transform: [
        {
          translateY: current.progress.interpolate({
            inputRange:  [0, 1],
            outputRange: [layouts.screen.height, 0],
          }),
        },
      ],
      // Slight scale on the card behind it (depth effect)
      opacity: current.progress.interpolate({
        inputRange:  [0, 1],
        outputRange: [0.85, 1],
      }),
    },
    overlayStyle: {
      opacity: current.progress.interpolate({
        inputRange:  [0, 1],
        outputRange: [0, 0.5],
      }),
    },
  }),
  transitionSpec: {
    open: {
      animation: 'spring',
      config: {
        damping:   22,
        stiffness: 180,
        mass:      1,
        overshootClamping: false,
        restDisplacementThreshold: 0.01,
        restSpeedThreshold:        0.01,
      },
    },
    close: {
      animation: 'timing',
      config: {
        duration: 360,
        easing: Easing.bezier(0.25, 0.46, 0.45, 0.94),
      },
    },
  },
};

/**
 * SLIDE-LEFT (standard iOS push)
 * Used for PhoneEntry → Verification and later steps.
 */
const slideLeftTransition = {
  gestureEnabled:   true,
  gestureDirection: 'horizontal',
  cardStyleInterpolator: ({ current, next, layouts }) => ({
    cardStyle: {
      transform: [
        {
          translateX: current.progress.interpolate({
            inputRange:  [0, 1],
            outputRange: [layouts.screen.width, 0],
          }),
        },
      ],
    },
    // The screen behind slides slightly left for parallax depth
    ...(next && {
      cardStyle: {
        transform: [
          {
            translateX: next.progress.interpolate({
              inputRange:  [0, 1],
              outputRange: [0, -layouts.screen.width * 0.3],
            }),
          },
        ],
      },
    }),
  }),
  transitionSpec: {
    open: {
      animation: 'spring',
      config: {
        damping:   24,
        stiffness: 200,
        mass:      1,
      },
    },
    close: {
      animation: 'timing',
      config: {
        duration: 300,
        easing: Easing.bezier(0.25, 0.46, 0.45, 0.94),
      },
    },
  },
};

// ─── Shared screen options ─────────────────────────────────────────────────
const SCREEN_OPTIONS = {
  headerShown: false,           // we build our own nav elements in each screen
  animationEnabled: true,
  // Keep the background consistent across the dark onboarding flow
  cardStyle: {
    backgroundColor: '#09071A', // matches COLORS.bgBase in every screen
  },
};

// ─── Navigator ─────────────────────────────────────────────────────────────
export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Landing"
        screenOptions={SCREEN_OPTIONS}
      >
        {/* ── Stage 1: Splash / Landing ── */}
        <Stack.Screen
          name="Landing"
          component={LandingScreen}
          options={{
            // Landing has no transition — it's the first screen
            animationEnabled: false,
          }}
        />

        {/* ── Stage 2: Phone Number Entry ──
            Slides UP from below (modal card feel)              */}
        <Stack.Screen
          name="PhoneEntry"
          component={PhoneEntryScreen}
          options={slideUpTransition}
        />

        {/* ── Stage 3: OTP Verification ──
            Slides LEFT (standard push)                         */}
        <Stack.Screen
          name="Verification"
          component={VerificationScreen}
          options={slideLeftTransition}
        />

        {/* ── Stage 4: Profile Setup ── */}
        <Stack.Screen
          name="ProfileSetup"
          component={ProfileSetupScreen}
          options={slideLeftTransition}
        />

        {/*
          ── Main App (Stage 5+) ──
          Uncomment once MainTabNavigator is built.
          Uses a fade transition so entering the app feels
          like the onboarding dissolves away.

        <Stack.Screen
          name="Main"
          component={MainTabNavigator}
          options={{
            gestureEnabled: false,
            cardStyleInterpolator: ({ current }) => ({
              cardStyle: {
                opacity: current.progress,
              },
            }),
            transitionSpec: {
              open:  { animation: 'timing', config: { duration: 400, easing: Easing.out(Easing.quad) } },
              close: { animation: 'timing', config: { duration: 300 } },
            },
          }}
        />
        */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}


/*
─── HOW TO WIRE THIS IN App.js ───────────────────────────────────────────────

  import { GestureHandlerRootView } from 'react-native-gesture-handler';
  import AppNavigator from './navigation/AppNavigator';

  export default function App() {
    return (
      <GestureHandlerRootView style={{ flex: 1 }}>
        <AppNavigator />
      </GestureHandlerRootView>
    );
  }

─── DEPENDENCIES NEEDED ──────────────────────────────────────────────────────

  expo install expo-linear-gradient expo-blur
  expo install react-native-gesture-handler react-native-reanimated
  npm install @react-navigation/native @react-navigation/stack
  expo install react-native-screens react-native-safe-area-context

─── FOLDER STRUCTURE ─────────────────────────────────────────────────────────

  /src
    /navigation
      AppNavigator.js          ← this file
    /screens
      LandingScreen.js         ← Stage 1 (already built)
      PhoneEntryScreen.js      ← Stage 2 (just built)
      VerificationScreen.js    ← Stage 3 (next)
      ProfileSetupScreen.js    ← Stage 4 (next)
    /constants
      colors.js                ← export COLORS from here for DRY access
      fonts.js                 ← export FONTS from here

──────────────────────────────────────────────────────────────────────────────
*/
